import {TOGGLE_THEME} from './Constant'

export const toggleTheme =()=>{
   return{
    type:TOGGLE_THEME
   };
};